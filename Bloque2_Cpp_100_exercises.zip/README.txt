Bloque 2 - Estructuras de Datos y Algoritmos Intermedios: 100 ejercicios en C++
Cada archivo es autocontenido y compilable con: g++ -std=c++17 exercise_XXX.cpp -o exercise_XXX

001: exercise_001.cpp - Intercambiar dos enteros usando punteros
002: exercise_002.cpp - Array dinámico y suma
003: exercise_003.cpp - Clase Persona con saludo
004: exercise_004.cpp - Factorial recursivo
005: exercise_005.cpp - Implementar pila usando array dinámico
006: exercise_006.cpp - Cola (queue) con lista enlazada simple
007: exercise_007.cpp - Intercambiar dos enteros usando punteros
008: exercise_008.cpp - Array dinámico y suma
009: exercise_009.cpp - Clase Persona con saludo
010: exercise_010.cpp - Factorial recursivo
011: exercise_011.cpp - Implementar pila usando array dinámico
012: exercise_012.cpp - Cola (queue) con lista enlazada simple
013: exercise_013.cpp - Intercambiar dos enteros usando punteros
014: exercise_014.cpp - Array dinámico y suma
015: exercise_015.cpp - Clase Persona con saludo
016: exercise_016.cpp - Factorial recursivo
017: exercise_017.cpp - Implementar pila usando array dinámico
018: exercise_018.cpp - Cola (queue) con lista enlazada simple
019: exercise_019.cpp - Intercambiar dos enteros usando punteros
020: exercise_020.cpp - Array dinámico y suma
021: exercise_021.cpp - Clase Persona con saludo
022: exercise_022.cpp - Factorial recursivo
023: exercise_023.cpp - Implementar pila usando array dinámico
024: exercise_024.cpp - Cola (queue) con lista enlazada simple
025: exercise_025.cpp - Intercambiar dos enteros usando punteros
026: exercise_026.cpp - Array dinámico y suma
027: exercise_027.cpp - Clase Persona con saludo
028: exercise_028.cpp - Factorial recursivo
029: exercise_029.cpp - Implementar pila usando array dinámico
030: exercise_030.cpp - Cola (queue) con lista enlazada simple
031: exercise_031.cpp - Intercambiar dos enteros usando punteros
032: exercise_032.cpp - Array dinámico y suma
033: exercise_033.cpp - Clase Persona con saludo
034: exercise_034.cpp - Factorial recursivo
035: exercise_035.cpp - Implementar pila usando array dinámico
036: exercise_036.cpp - Cola (queue) con lista enlazada simple
037: exercise_037.cpp - Intercambiar dos enteros usando punteros
038: exercise_038.cpp - Array dinámico y suma
039: exercise_039.cpp - Clase Persona con saludo
040: exercise_040.cpp - Factorial recursivo
041: exercise_041.cpp - Implementar pila usando array dinámico
042: exercise_042.cpp - Cola (queue) con lista enlazada simple
043: exercise_043.cpp - Intercambiar dos enteros usando punteros
044: exercise_044.cpp - Array dinámico y suma
045: exercise_045.cpp - Clase Persona con saludo
046: exercise_046.cpp - Factorial recursivo
047: exercise_047.cpp - Implementar pila usando array dinámico
048: exercise_048.cpp - Cola (queue) con lista enlazada simple
049: exercise_049.cpp - Intercambiar dos enteros usando punteros
050: exercise_050.cpp - Array dinámico y suma
051: exercise_051.cpp - Clase Persona con saludo
052: exercise_052.cpp - Factorial recursivo
053: exercise_053.cpp - Implementar pila usando array dinámico
054: exercise_054.cpp - Cola (queue) con lista enlazada simple
055: exercise_055.cpp - Intercambiar dos enteros usando punteros
056: exercise_056.cpp - Array dinámico y suma
057: exercise_057.cpp - Clase Persona con saludo
058: exercise_058.cpp - Factorial recursivo
059: exercise_059.cpp - Implementar pila usando array dinámico
060: exercise_060.cpp - Cola (queue) con lista enlazada simple
061: exercise_061.cpp - Intercambiar dos enteros usando punteros
062: exercise_062.cpp - Array dinámico y suma
063: exercise_063.cpp - Clase Persona con saludo
064: exercise_064.cpp - Factorial recursivo
065: exercise_065.cpp - Implementar pila usando array dinámico
066: exercise_066.cpp - Cola (queue) con lista enlazada simple
067: exercise_067.cpp - Intercambiar dos enteros usando punteros
068: exercise_068.cpp - Array dinámico y suma
069: exercise_069.cpp - Clase Persona con saludo
070: exercise_070.cpp - Factorial recursivo
071: exercise_071.cpp - Implementar pila usando array dinámico
072: exercise_072.cpp - Cola (queue) con lista enlazada simple
073: exercise_073.cpp - Intercambiar dos enteros usando punteros
074: exercise_074.cpp - Array dinámico y suma
075: exercise_075.cpp - Clase Persona con saludo
076: exercise_076.cpp - Factorial recursivo
077: exercise_077.cpp - Implementar pila usando array dinámico
078: exercise_078.cpp - Cola (queue) con lista enlazada simple
079: exercise_079.cpp - Intercambiar dos enteros usando punteros
080: exercise_080.cpp - Array dinámico y suma
081: exercise_081.cpp - Clase Persona con saludo
082: exercise_082.cpp - Factorial recursivo
083: exercise_083.cpp - Implementar pila usando array dinámico
084: exercise_084.cpp - Cola (queue) con lista enlazada simple
085: exercise_085.cpp - Intercambiar dos enteros usando punteros
086: exercise_086.cpp - Array dinámico y suma
087: exercise_087.cpp - Clase Persona con saludo
088: exercise_088.cpp - Factorial recursivo
089: exercise_089.cpp - Implementar pila usando array dinámico
090: exercise_090.cpp - Cola (queue) con lista enlazada simple
091: exercise_091.cpp - Intercambiar dos enteros usando punteros
092: exercise_092.cpp - Array dinámico y suma
093: exercise_093.cpp - Clase Persona con saludo
094: exercise_094.cpp - Factorial recursivo
095: exercise_095.cpp - Implementar pila usando array dinámico
096: exercise_096.cpp - Cola (queue) con lista enlazada simple
097: exercise_097.cpp - Intercambiar dos enteros usando punteros
098: exercise_098.cpp - Array dinámico y suma
099: exercise_099.cpp - Clase Persona con saludo
100: exercise_100.cpp - Factorial recursivo
